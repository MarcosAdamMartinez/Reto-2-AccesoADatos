package reto2.parte1_1;

public class LibroConAlias {
	private String titulo;
    private String autor;
    private int año;
    private int ventas;
    
    public LibroConAlias(String titulo, String autor, int año, int ventas) {
        this.titulo = titulo;
        this.autor = autor;
        this.año = año;
        this.ventas = ventas;
    }
}
