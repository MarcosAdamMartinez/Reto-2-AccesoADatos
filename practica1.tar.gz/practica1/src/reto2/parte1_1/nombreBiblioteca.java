package reto2.parte1_1;

public class nombreBiblioteca {
	
	 private String nombre;
	 
	 public nombreBiblioteca() { }
	 
	 
     public nombreBiblioteca(String nombre) {
             this.nombre = nombre;
     }
     
     public String getName() {
             return nombre;
     }
     
     public void setName(String nombre) {
    	 this.nombre = nombre;
 }
}
