/**
 * 
 */
/**
 * 
 */
module practica1 {
}